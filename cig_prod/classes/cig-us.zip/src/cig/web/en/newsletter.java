/** Function: register a user and enter a row into database
 *  @author: Debbie Zhang
 *  @version: 1.0.0
 */

package cig.web.en;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.InetAddress;
import com.cig.db.DBConnectionManager;


public class newsletter extends HttpServlet
{
	private DBConnectionManager connectionManager;
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		connectionManager = DBConnectionManager.getInstance();
	}
	public void destroy()
	{
		connectionManager.release();
		super.destroy();
	}
	//-----------------------------------------------

   public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
   {
	  res.setContentType("text/html");
	  PrintWriter out = res.getWriter();
	  String localIP = CbstUtil.getLocalIP("127.0.0.1");

	  //compose sql statement
	  String sql = "insert into newsletter "+
		 "(FIRSTNAME,LASTNAME,EMAIL,COMPANY,VERSIONENGLISH,VERSIONCHINESE,AREA, ID) "+
		 " values ("+
	 "'"+replace.replacequote(req.getParameter("firstname"))+"', "+
	 "'"+replace.replacequote(req.getParameter("lastname"))+"', "+
	 "'"+replace.replacequote(req.getParameter("email"))+"', "+
	 "'"+replace.replacequote(req.getParameter("company"))+"', "+
//	 "'"+replace.replacequote(req.getParameter("identifier"))+"', "+
//	 "'"+replace.replacequote(req.getParameter("sector"))+"', "+
//	 "'"+replace.replacequote(req.getParameter("othersector"))+"', "+
	 "'"+req.getParameter("versionenglish")+"', "+
	 "'"+req.getParameter("versionchinese")+"', "+
		 "'"+req.getParameter("area")+ "', ";

		java.sql.Connection conn = this.connectionManager.getConnection(Include.DBPOOLNAME);
		if(conn == null)
		{
			out.println("<html><body><B>Can not get connection from database connection-pool.</B></body></html>");
			return;
		}
		java.sql.Statement stmt = null;
		try
		{
			stmt = conn.createStatement();
			String caseID = null;
			ResultSet rs = stmt.executeQuery("select Seq_newsletter_ID.nextVal from dual");
			if(!rs.next()) throw new SQLException("Can't get Entrepreneure.ID from SEQUENCE.");
			else caseID = rs.getString(1);
			stmt.executeUpdate(sql + caseID + ")");
		}
		catch(SQLException exc)
		{
			out.println("<html><body><B>There is some error occure in the input field.</B><br>" + exc.toString() + "<br><B>Please use back button to verify.  Thanks</B></body></html>");
			return;
		}
		finally
		{
			try
			{
				if(stmt != null) stmt.close();
				if(conn != null) this.connectionManager.freeConnection(Include.DBPOOLNAME, conn);
			}
			catch(java.sql.SQLException ex)
			{
			}
		}

		//display some confirmation page
		BufferedReader inHeader = new BufferedReader(new FileReader(Include.HEADER));
		String s = null;
		while ((s = inHeader.readLine()) != null)
			out.println(s);
		inHeader.close();

		out.println("<p><br><br><br><br><br>Dear "+req.getParameter("firstname")+"</p>");
		out.println("<p>Thanks for your interest in China Internet Group.We have added you to our mailing list, and you can expect to receive periodic newsletter from us about updates in the internet environment in China, specific investment opportunities and other events we will hold from time to time. Please feel free to contact us if you have any questions.</p>");
		out.println("<p>Sincerely,<BR>China Internet Group</p>");

		BufferedReader inFooter = new BufferedReader(new FileReader(Include.FOOTER));
		while ((s = inFooter.readLine()) != null)
			out.println(s);
		inFooter.close();
   }//end of doPost
}
