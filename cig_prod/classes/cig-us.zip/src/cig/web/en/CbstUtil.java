package cig.web.en;

import java.io.*;
import java.util.*;
import java.sql.*;
import java.net.InetAddress;

import javax.servlet.*;
import javax.servlet.http.*;


public class CbstUtil
{

	public static String getLocalIP(String defaultIP)
	{
		String localIP = defaultIP;
		try
		{
			localIP = InetAddress.getLocalHost().getHostAddress();
		}
		catch(Exception ex)
		{}
		return localIP;
	}

	public static void sendPage(HttpServletRequest req, HttpServletResponse res, String IP, String page) throws IOException  
	{
		try{
			res.sendRedirect(req.getScheme() + "://" + IP + ":" + req.getServerPort() + "/" + page);
		}
		catch(IOException ex)
		{
			throw ex;
		}
			
		return;
	}
}
