/** Function: register a user and enter a row into database
 *  @author: Debbie Zhang
 *  @version: 1.0.0
 */

package cig.web.en;

import java.io.*;
import java.util.*;
import java.util.Date;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.InetAddress;
import com.cig.db.DBConnectionManager;


public class register extends HttpServlet
{
	private DBConnectionManager connectionManager;
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		connectionManager = DBConnectionManager.getInstance();
	}
	public void destroy()
	{
		connectionManager.release();
		super.destroy();
	}
	//-----------------------------------------------

   public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
   {
	  res.setContentType("text/html");
	  PrintWriter out = res.getWriter();
	  String localIP = CbstUtil.getLocalIP("127.0.0.1");


	  //process some data
	  /*
	String cmpInfo = req.getParameter("cmpinfo1");
	  String cmpInfo1=cmpInfo;
	  String cmpInfo2="";
	  if(cmpInfo.length() >= 255)
	  {
		 cmpInfo1= cmpInfo.substring(0,254);
		 cmpInfo2= cmpInfo.substring(254,500);
	  }

	  String bioInfo = req.getParameter("bioinfo1");
	  String bioInfo1=bioInfo;
	  String bioInfo2="";
	  if(bioInfo.length() >= 255)
	  {
		 bioInfo1= bioInfo.substring(0,254);
		 bioInfo2= bioInfo.substring(254,500);
	  }
	*/

	  //compose sql statement
		//create a uniq ID
	long longID = new Date().getTime();
	long segment = (longID / 1000000)*1000000;
	String registerID = (new Long(longID - segment)).toString();

	  String sql = "insert into evregister "+
		 "(ID,EVENTID, FIRSTNAME, LASTNAME, TITLE, COMPANY, ADDRESS1, ADDRESS2, CITY, "+
		 "STATE, ZIP, CTRY, TELEPHONE, FAX, EMAIL, TYPE, TYPEOTHER, HEAR, HEAROTHER,"+
		 //"STATE, ZIP, CTRY, TELEPHONE, FAX, EMAIL, TYPE, TYPEOTHER,"+
		 //"STATE, ZIP, CTRY, TELEPHONE, FAX, EMAIL, TYPE, "+
		 "PAYMENT, "+
		 "CREDITTYPE, CREDITCARD, EXPIREDATE, CARDHOLDER, HOTELFLAG, ROOM, ARRIVAL, DEPARTURE, SMOKE, DISCOUNT, CUSNOTES) "+
		 " values ("+
	   "'"+registerID+"', "+
	   "'"+replace.replacequote(req.getParameter("eventid"))+"', "+
	   "'"+replace.replacequote(req.getParameter("firstname"))+"', "+
		 "'"+replace.replacequote(req.getParameter("lastname"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("title"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("company"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("address1"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("address2"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("city"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("state"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("zip"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("ctry"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("telephone"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("fax"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("email"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("type"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("typeother"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("hear"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("hearother"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("payment"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("credittype"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("creditcard"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("expiredate"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("cardholder"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("hotelflag"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("room"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("arrival"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("departure"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("smoke"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("discount"))+ "', "+
		 "'"+replace.replacequote(req.getParameter("cusnotes"))+ "') ";

		String replyMsg = "The regular registration price will be charged to your credit card.";
		java.sql.Connection conn = this.connectionManager.getConnection(Include.DBPOOLNAME);
		if(conn == null)
		{
			out.println("<html><body><B>Can not get connection from database connection-pool.</B></body></html>");
			return;
		}
		java.sql.Statement stmt = null;
		try
		{
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);

			//based on whether user is a cig club member to decide their registration price
			if(req.getParameter("clubid")!=null)   //user claims he is member
			{
				String sql2 = "select ID from club where (ID="+req.getParameter("clubid")+")";
				ResultSet rs = stmt.executeQuery(sql2);
				if (rs.next() == true)  //really is member
				{
					String sql3="select * from evregister where clubid="+req.getParameter("clubid");
					ResultSet rs2 = stmt.executeQuery(sql3);
					if (rs2.next() == true)  //has been used already
					{
						String name=rs2.getString("firstname")+" "+rs2.getString("lastname");
						replyMsg = "You CIG club membership has been used to register for "+name+".  The regular registration price will be charged to your credit card.";
					}
					else
					{
						String sql4="update evregister set clubflag='Y', clubid="+req.getParameter("clubid")+" where email='"+req.getParameter("email")+ "'";
						replyMsg ="The discounted CIG member price will be charged to your credit card account.";
						stmt.executeUpdate(sql4);
					}
				}
			}
		}
		catch(SQLException exc)
		{
			out.println("<html><body><B>There is some error occure in the input field.</B><br>" + exc.toString() + "<br><B>Please use back button to verify.  Thanks</B></body></html>");
			return;
		}
		finally
		{
			try
			{
				if(stmt != null) stmt.close();
				if(conn != null) this.connectionManager.freeConnection(Include.DBPOOLNAME, conn);
			}
			catch(java.sql.SQLException ex)
			{
			}
		}
		//display some confirmation page
		BufferedReader inHeader = new BufferedReader(new FileReader(Include.HEADER));
		String s = null;
		while ((s = inHeader.readLine()) != null)
			out.println(s);
		inHeader.close();

		out.println("<html><head><title></title></head><body><p align=center><p><br><br><br><br><br>Dear "+req.getParameter("firstname")+"</p>");
		out.println("<P align=left>Thank you for your interest in this event.<br>Your registration ID number is :"+registerID+". Please keep it for record. We have added you to our registertration list."+replyMsg+"  Please feel free to contact us if you have any questions.</p>");
		out.println("<P align=left>Sincerely,<BR>China Internet Group");

		BufferedReader inFooter = new BufferedReader(new FileReader(Include.FOOTER));
		while ((s = inFooter.readLine()) != null)
			out.println(s);
		inFooter.close();
   }//end of doPost
}
