package cig.web.en;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2000
 * Company:      www.CIG.com.cn
 * @author Javan
 * @version 1.0
 */

public class Include
{
	public static String DBPOOLNAME="cigus";
	public static String HEADER = "/home/httpd/html/cig-us/english/replyheader";
	public static String FOOTER = "/home/httpd/html/cig-us/english/replyfooter";
	//public static String HEADER="/www/docs/cig-us/english/replyheader";
	//public static String FOOTER="/www/docs/cig-us/english/replyfooter";

	public static String MAILSERVER="202.96.140.7";
	public static int MAILPORT=25;
}