/** Function: register a user and enter a row into database
 *  @version: 1.1.0
 */

package cig.web.en;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.InetAddress;
import com.cig.db.DBConnectionManager;

public class email extends HttpServlet
{
	private DBConnectionManager connectionManager;
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		connectionManager = DBConnectionManager.getInstance();
	}
	public void destroy()
	{
		connectionManager.release();
		super.destroy();
	}
	//-----------------------------------------------

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{/*
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		String localIP = CbstUtil.getLocalIP("127.0.0.1");

		//compose sql statement
		String sql = "select FIRSTNAME,EMAIL from newsletter "+
		"(FIRSTNAME,LASTNAME,EMAIL,COMPANY,VERSIONENGLISH,VERSIONCHINESE,AREA) "+
		" values ("+
		"'"+req.getParameter("firstname")+"', "+
		"'"+req.getParameter("lastname")+"', "+
		"'"+req.getParameter("email")+"', "+
		"'"+req.getParameter("company")+"', "+
		//	 "'"+req.getParameter("identifier")+"', "+
		//	 "'"+req.getParameter("sector")+"', "+
		//	 "'"+req.getParameter("othersector")+"', "+
		"'"+req.getParameter("versionenglish")+"', "+
		"'"+req.getParameter("versionchinese")+"', "+
		"'"+req.getParameter("area")+ "')";

		String memberID=null;
		java.sql.Connection conn = this.connectionManager.getConnection(Include.DBPOOLNAME);
		java.sql.Statement stmt = null;
		try
		{

		}
		catch(SQLException exc)
		{
			out.println("<html><body><B>There is some error occure in the input field.</B><br>" + exc.toString() + "<br><B>Please use back button to verify.  Thanks</B></body></html>");
		}
		finally
		{
			try
			{
				if(stmt != null) stmt.close();
				if(conn != null) this.connectionManager.freeConnection(Include.DBPOOLNAME, conn);
			}
			catch(java.sql.SQLException ex)
			{
			}
		}
		try
		{
			mDBConnection.executeSQL(sql);

			//display some confirmation page
			String outPage = Header;
			outPage += "<p><br><br><br><br><br>Dear "+req.getParameter("firstname")+"</p>";
			outPage += "<p>Thanks for your interest in China Internet Group.We have added you to our mailing list, and you can expect to receive periodic newsletter from us about updates in the internet environment in China, specific investment opportunities and other events we will hold from time to time. Please feel free to contact us if you have any questions.</p>";
			outPage += "<p>Sincerely,<BR>China Internet Group</p>";

			outPage += Footer;
			out.println(outPage);

		}
		catch(SQLException ex)
		{
			log("Cannot execute query: " + ex.getMessage());
			out.println("<html><body><B>There is some error occure in the input field.  Please use back button to verify.  Thanks</B></body></html>");
		}*/
	}//end of doPost
}
