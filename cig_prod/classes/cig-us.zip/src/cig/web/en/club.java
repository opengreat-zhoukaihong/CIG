/** Function: register a user and enter a row into database
 *  @author: Debbie Zhang
 *  @version: 1.0.0
 */

package cig.web.en;

import java.io.*;
import java.util.Date;
import java.util.*;
import java.util.Random;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.InetAddress;
import com.cig.db.DBConnectionManager;

public class club extends HttpServlet
{
	private DBConnectionManager connectionManager;
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		connectionManager = DBConnectionManager.getInstance();
	}
	public void destroy()
	{
		connectionManager.release();
		super.destroy();
	}
	//-----------------------------------------------
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		//String localIP = CbstUtil.getLocalIP("127.0.0.1");
		//compose sql statement
		//create a uniq ID
		long longID = new Date().getTime();
		long segment = (longID / 1000000)*1000000;
		String clubID = (new Long(longID - segment)).toString();

		String sql = "insert into club "+
		"(ID, FIRSTNAME,LASTNAME,EMAIL,PHONE,FAX,ADDRESS,"+
		"COMPANY,IDENTIFIER,"+
		"TYPE,CARDTYPE,CARDNUMBER,CARDEXPIRE) "+
		" values ("+
		"'"+clubID+"', "+
		"'"+replace.replacequote(req.getParameter("firstname"))+"', "+
		"'"+replace.replacequote(req.getParameter("lastname"))+"', "+
		"'"+req.getParameter("email")+"', "+
		"'"+req.getParameter("phone")+"', "+
		"'"+req.getParameter("fax")+"', "+
		"'"+replace.replacequote(req.getParameter("address"))+"', "+
		"'"+replace.replacequote(req.getParameter("company"))+"', "+
		"'"+req.getParameter("identifier")+"', "+
		"'"+req.getParameter("type")+"', "+
		"'"+req.getParameter("cardtype")+"', "+
		"'"+req.getParameter("cardnumber")+"', "+
		"'"+req.getParameter("cardexpire")+ "')";
		String sql2 = "select ID from club where (EMAIL='"+req.getParameter("email")+"')";
		//
		String memberID=null;
		java.sql.Connection conn = this.connectionManager.getConnection(Include.DBPOOLNAME);
		if(conn == null)
		{
			out.println("<html><body><B>Can not get connection from database connection-pool.</B></body></html>");
			return;
		}
		java.sql.Statement stmt = null;
		try
		{
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			//get the member id number for user to keep
			ResultSet rs = stmt.executeQuery(sql2);
			if(rs.next()==true)
			{
				memberID = rs.getString("ID");
			}
		}
		catch(SQLException exc)
		{
			out.println("<html><body><B>There is some error occure in the input field.</B><br>" + exc.toString() + "<br><B>Please use back button to verify.  Thanks</B></body></html>");
			return;
		}
		finally
		{
			try
			{
				if(stmt != null) stmt.close();
				if(conn != null) this.connectionManager.freeConnection(Include.DBPOOLNAME, conn);
			}
			catch(java.sql.SQLException ex)
			{
			}
		}
		//display some confirmation page
		BufferedReader inHeader = new BufferedReader(new FileReader(Include.HEADER));
		String s = null;
		while ((s = inHeader.readLine()) != null)
			out.println(s);
		inHeader.close();

		out.println("<br><br><br><br><br>");
		out.println("<p align=center><p>Dear "+req.getParameter("firstname")+",</p>");
		out.println("<P>Thank you for joining CIG club!  Your member ID is "+memberID+".  Please keep it for your record. Inaddition to receiving our email newsletter, you will be be eligible for discounts on future CIG hosted events, conferences, and seminars.</p>");
		out.println("<P>Sincerely,<BR>China Internet Group</p></p>");

		BufferedReader inFooter = new BufferedReader(new FileReader(Include.FOOTER));
		while ((s = inFooter.readLine()) != null)
			out.println(s);
		inFooter.close();
	}//end of doPost
}
