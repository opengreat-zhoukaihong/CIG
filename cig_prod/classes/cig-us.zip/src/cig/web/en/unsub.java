/** Function: unsubscribe newsletter
 *  @author: Gang Zhao
 *  @version: 1.0.0
 */

package cig.web.en;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.InetAddress;
import com.cig.db.DBConnectionManager;


public class unsub extends HttpServlet
{
	private DBConnectionManager connectionManager;
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		connectionManager = DBConnectionManager.getInstance();
	}
	public void destroy()
	{
		connectionManager.release();
		super.destroy();
	}
	//-----------------------------------------------

   public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
   {
	  res.setContentType("text/html");
	  PrintWriter out = res.getWriter();
	  String localIP = CbstUtil.getLocalIP("127.0.0.1");

	  //compose sql statement
	  String sql = "insert into unsub "+
		 "(EMAIL) "+
		 " values ("+
	 "'"+req.getParameter("email")+ "')";

	  java.sql.Connection conn = this.connectionManager.getConnection(Include.DBPOOLNAME);
		if(conn == null)
		{
			out.println("<html><body><B>Can not get connection from database connection-pool.</B></body></html>");
			return;
		}
		java.sql.Statement stmt = null;
		try
		{
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
		}
		catch(SQLException exc)
		{
			out.println("<html><body><B>There is some error occure in the input field.</B><br>" + exc.toString() + "<br><B>Please use back button to verify.  Thanks</B></body></html>");
			return;
		}
		finally
		{
			try
			{
				if(stmt != null) stmt.close();
				if(conn != null) this.connectionManager.freeConnection(Include.DBPOOLNAME, conn);
			}
			catch(java.sql.SQLException ex)
			{
			}
		}

		//display some confirmation page
		BufferedReader inHeader = new BufferedReader(new FileReader(Include.HEADER));
		String s = null;
		while ((s = inHeader.readLine()) != null)
			out.println(s);
		inHeader.close();

		out.println("<p><br><br><br><br><br>Dear "+"</p>");
		out.println("<p>You have unsubscribed this newsletter.</p>");
		out.println("<p>Sincerely,<BR>China Internet Group</p>");

		BufferedReader inFooter = new BufferedReader(new FileReader(Include.FOOTER));
		while ((s = inFooter.readLine()) != null)
			out.println(s);
		inFooter.close();
   }//end of doPost

}
