
package cig.web.en;

import java.io.*;
import java.util.*;
import java.util.Date;


public class replace
{

   public static String replacequote(String in)
   {
	   String s=in;
	   //String newstring=s.replace('''," ");
		String newstring="";
		StringTokenizer st = new StringTokenizer(s,"'");
		if (st.hasMoreTokens()){
			newstring=st.nextToken();
		}
		while (st.hasMoreTokens()) {
				newstring=newstring+"''"+st.nextToken();
		}
		return newstring;
	}

}
