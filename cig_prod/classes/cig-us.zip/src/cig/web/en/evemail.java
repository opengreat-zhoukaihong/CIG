/** Function: register a user and enter a row into database
 *  @author: Debbie Zhang
 *  @version: 1.0.0
 */

package cig.web.en;

import java.io.*;
import java.util.*;
import java.sql.*;
import java.net.*;
import java.rmi.RemoteException;

import javax.servlet.*;
import javax.servlet.http.*;
import java.net.InetAddress;


public class evemail extends HttpServlet
{

   //IDBConnector mDBConnection = null;
   String Header="";
   String Footer="";

   final static private String 	_mailServer = "mail.cig-us.com";
   final static private int 	_mailPort 	= 25; // default for mailserver
   private String localIP=null;
   private Socket socket=null;
   private BufferedReader _inStream;
   private PrintStream _outStream;



   public void init(ServletConfig config) throws ServletException
   {
	  super.init(config);
	  try
	  {
		 //mDBConnection = new COdbcDBConnector();
		 //mDBConnection.connect("cigwebDB", "admin", "admin");
	   BufferedReader inHeader = new BufferedReader(new FileReader("C:\\wwwroot\\cigweb\\replyHeader"));
	   String s = null;
	   while ((s = inHeader.readLine()) != null)
	   {
		Header+= s + "\n";
	   }

	   inHeader.close();

		 BufferedReader inFooter = new BufferedReader(new FileReader("C:\\wwwroot\\cigweb\\replyFooter"));
	   while ((s = inFooter.readLine()) != null)
	   {
		Footer += s + "\n";
	   }

		inFooter.close();

	  }
	  catch(IOException ioex)
	{
		throw new ServletException("IO ERROR: cannot reply message file\n" + ioex.getMessage());
	}

   }

   public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
   {
	  res.setContentType("text/html");
	  PrintWriter out = res.getWriter();
	  localIP = CbstUtil.getLocalIP("127.0.0.1");

	  //get input
	  String emailTo=req.getParameter("emailto");
	String emailFrom=req.getParameter("emailfrom");
	String subject=req.getParameter("subject");

	String msg="From:"+emailFrom+"\n";
	msg+="To:"+emailTo+"\n";
	msg+="Subject:"+subject+"\n";
	msg+=req.getParameter("message")+"\n\n";
	msg+="China Internet Group is the first integrated incubator for Internet business in China.  We co-found and develop early stage Internet companies to rapidly become market leaders.  Please check out our exciting new events at http://www.chinainternetgroup.com/english/cig_club_events.htm \n";

	try{
		socket = new Socket (_mailServer, _mailPort);
		sendMsg(emailFrom,emailTo,msg);
	  }
	catch(Exception ex)
	{
		log("Cannot create socket:"+ex.getMessage());
		out.println("<html><body><B>There is some error occure in the input field.  Please use back button to verify.  Thanks</B></body></html>");
	}



		//display some confirmation page
		String outPage = Header;
	  outPage += "<br><br><br><br><br>Thank you for sending event information to your friend !";
	  outPage += "<P>Sincerely,<BR>China Internet Group</p></p>";
		outPage += Footer;
		out.println(outPage);
   }//end of doPost

	private void sendMsg(String sender, String recipient, String message)
	{
	int b = 0;
	try
	{
		_inStream = new BufferedReader(
			new InputStreamReader (socket.getInputStream()));
		_outStream = new PrintStream(socket.getOutputStream());

		String reply = _inStream.readLine();


		lineOut ("HELO " + localIP, true);
		lineOut ("MAIL FROM: " + sender, true);
		lineOut ("RCPT TO: " + recipient, true);
		lineOut ("DATA", true);
		lineOut (message, false);
		lineOut ("\n.\n", false);
		lineOut("QUIT", false);
	}
	catch (RemoteException ex1)
	{
		_outStream.println( "\n.\n" );
	}
	catch (IOException ex)
	{
		_outStream.println( "\n.\n" );
	}
	}


/**
	 * Writes a line to the ouput stream, echoing any feedback.
	 * @param	hasReply
	 * @param	outline
	 */
	private void lineOut (String lineOut, boolean hasReply)
		throws IOException, RemoteException
	{
	   _outStream.println (lineOut);
	   _outStream.flush();
	   if (hasReply)
	   {
		String s = _inStream.readLine();

		if(s.startsWith("5"))
		{
			throw new RemoteException( "ERROR while communicating with Mailserver: \n" + s);
		}
	   }
	}

}
