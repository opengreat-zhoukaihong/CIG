/** Function: entrepreneure to enter info
 *  @author: Debbie Zhang
 *  @version: 1.0.0
 */

package cig.web.en;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.InetAddress;
import com.cig.db.DBConnectionManager;


public class evspeaker extends HttpServlet
{
	private DBConnectionManager connectionManager;
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		connectionManager = DBConnectionManager.getInstance();
	}
	public void destroy()
	{
		connectionManager.release();
		super.destroy();
	}
	//-----------------------------------------------
   public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
   {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		String localIP = CbstUtil.getLocalIP("127.0.0.1");

		//handle long text area
		String experience=req.getParameter("experience");
		String experience1=experience;
		String experience2="";
		if(experience.length() >= 255)
		{
			experience1=experience.substring(0,254);
			experience2=experience.substring(254,500);
		}

		String qualification=req.getParameter("qualification");
		String qualification1=qualification;
		String qualification2="";
		if(qualification.length() >= 255)
		{
			qualification1=qualification.substring(0,254);
			qualification2=qualification.substring(254,500);
		}
		//compose sql statement
	  String sql = "insert into evspeaker "+
		 "(EVENT,FIRSTNAME,LASTNAME,TITLE,COMPANY,ADDRESS,"+
	   "CITY,STATE,ZIP,PHONE,FAX,EMAIL,COUNTRY,"+
	   "EXPERIENCE1,EXPERIENCE2,QUALIFICATION1,QUALIFICATION2,"+
		   "SELFFIRSTNAME,SELFLASTNAME,SELFTITLE,SELFCOMPANY,SELFADDRESS,"+
	   "SELFCITY,SELFSTATE,SELFZIP,SELFPHONE,SELFFAX,SELFEMAIL,"+
	   "SELFCOUNTRY, ID)"+
		 " values ("+
	   "'"+replace.replacequote(req.getParameter("event"))+"', "+
	   "'"+replace.replacequote(req.getParameter("firstname"))+"', "+
	   "'"+replace.replacequote(req.getParameter("lastname"))+"', "+
	   "'"+replace.replacequote(req.getParameter("title"))+"', "+
	   "'"+replace.replacequote(req.getParameter("company"))+"', "+
	   "'"+replace.replacequote(req.getParameter("address"))+"', "+
	   "'"+replace.replacequote(req.getParameter("city"))+"', "+
	   "'"+replace.replacequote(req.getParameter("state"))+"', "+
	   "'"+replace.replacequote(req.getParameter("zip"))+"', "+
	   "'"+replace.replacequote(req.getParameter("phone"))+"', "+
		   "'"+replace.replacequote(req.getParameter("fax"))+"', "+
	   "'"+replace.replacequote(req.getParameter("email"))+"', "+
	   "'"+replace.replacequote(req.getParameter("country"))+"', "+
	   "'"+replace.replacequote(experience1)+"', "+
	   "'"+replace.replacequote(experience2)+"', "+
	   "'"+replace.replacequote(qualification1)+"', "+
	   "'"+replace.replacequote(qualification2)+"', "+
	   "'"+replace.replacequote(req.getParameter("firstname2"))+"', "+
	   "'"+replace.replacequote(req.getParameter("lastname2"))+"', "+
	   "'"+replace.replacequote(req.getParameter("title2"))+"', "+
	   "'"+replace.replacequote(req.getParameter("company2"))+"', "+
	   "'"+replace.replacequote(req.getParameter("address2"))+"', "+
	   "'"+replace.replacequote(req.getParameter("city2"))+"', "+
	   "'"+replace.replacequote(req.getParameter("state2"))+"', "+
	   "'"+replace.replacequote(req.getParameter("zip2"))+"', "+
	   "'"+replace.replacequote(req.getParameter("phone2"))+"', "+
		   "'"+replace.replacequote(req.getParameter("fax2"))+"', "+
	   "'"+replace.replacequote(req.getParameter("email2"))+"', "+
	   "'"+replace.replacequote(req.getParameter("country2"))+"', ";

		java.sql.Connection conn = this.connectionManager.getConnection(Include.DBPOOLNAME);
		if(conn == null)
		{
			out.println("<html><body><B>Can not get connection from database connection-pool.</B></body></html>");
			return;
		}
		java.sql.Statement stmt = null;
		try
		{
			stmt = conn.createStatement();
			String caseID = null;
			ResultSet rs = stmt.executeQuery("select seq_evspeaker_id.nextVal from dual");
			if(!rs.next()) throw new SQLException("Can't get Entrepreneure.ID from SEQUENCE.");
			else caseID = rs.getString(1);
			stmt.executeUpdate(sql + caseID + ")");
		}
		catch(SQLException exc)
		{
			out.println("<html><body><B>There is some error occure in the input field.</B><br>" + exc.toString() + "<br><B>Please use back button to verify.  Thanks</B></body></html>");
			return;
		}
		finally
		{
			try
			{
				if(stmt != null) stmt.close();
				if(conn != null) this.connectionManager.freeConnection(Include.DBPOOLNAME, conn);
			}
			catch(java.sql.SQLException ex)
			{
			}
		}

		//display some confirmation page
		BufferedReader inHeader = new BufferedReader(new FileReader(Include.HEADER));
		String s = null;
		while ((s = inHeader.readLine()) != null)
			out.println(s);
		inHeader.close();

		out.println("&nbsp;&nbsp;<br><br><br><br><br>Thank you for nominating a speaker! We appreciate your interest in China Internet Group and our exciting programs and conferences. We are continually improving our services network to provide our clients with the most insightful and useful information provided by expert speakers on the internet industry. Your opinions and recommendations are an important part of this process and we will take your nomination under consideration for future events. ");
		out.println("<P>Sincerely,<BR>China Internet Group</p></p>");

		BufferedReader inFooter = new BufferedReader(new FileReader(Include.FOOTER));
		while ((s = inFooter.readLine()) != null)
			out.println(s);
		inFooter.close();
	}//end of doPost
}
