/** Function: entrepreneure to enter info
 *  @author: Debbie Zhang
 *  @version: 1.0.0
 */

package cig.web.en;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.InetAddress;
import com.cig.db.DBConnectionManager;


public class entre extends HttpServlet
{
	private DBConnectionManager connectionManager;
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		connectionManager = DBConnectionManager.getInstance();
	}
	public void destroy()
	{
		connectionManager.release();
		super.destroy();
	}
	//-----------------------------------------------

   public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
   {
	  res.setContentType("text/html");
	  PrintWriter out = res.getWriter();
	 // String localIP = CbstUtil.getLocalIP("127.0.0.1");

	  //compose sql statement
	  String sql = "insert into entrepreneure "+
		 "(FIRSTNAME,LASTNAME,COMPANY,ADDRESS,CITY,STATE,ZIP,PHONE,EMAIL,FAX,URL,"+
	   "IDEASUMMARY, ID)"+
	   //BUSMODEL,REVMODEL,TARGETUSER,"+
//	   "FUTUREMARKETSIZE,MARKETSIZE,FOUNDER,MANAGEMENT,"+
//	   "PARTNER,FOUNDTIME,COMPETITORGLOBAL,COMPETITORCHINA,"+
//	   "COMPETITORADVANTAGE,REGULATORY,BARRIER,MONEYRAISING,"+
//	   "EQUITYGIVEUP,BURNRATE,MILESTONE,"+
//	   "USEOFMONEY) "+
		 " values ("+
	   "'"+replace.replacequote(req.getParameter("firstname"))+"', "+
	   "'"+replace.replacequote(req.getParameter("lastname"))+"', "+
	   "'"+replace.replacequote(req.getParameter("company"))+"', "+
	   "'"+replace.replacequote(req.getParameter("address"))+"', "+
	   "'"+replace.replacequote(req.getParameter("city"))+"', "+
	   "'"+replace.replacequote(req.getParameter("state"))+"', "+
	   "'"+replace.replacequote(req.getParameter("zip"))+"', "+
		 "'"+replace.replacequote(req.getParameter("phone"))+"', "+
		 "'"+replace.replacequote(req.getParameter("email"))+"', "+
		 "'"+replace.replacequote(req.getParameter("fax"))+"', "+
	   "'"+replace.replacequote(req.getParameter("url"))+"', "+
	   "'"+replace.replacequote(req.getParameter("ideasummary"))+"', ";
//	   "'"+req.getParameter("busmodel")+"', "+
//	   "'"+req.getParameter("revmodel")+"', "+
//	   "'"+req.getParameter("targetuser")+"', "+
//	   "'"+req.getParameter("futuremarketsize")+"', "+
//	   "'"+req.getParameter("marketsize")+"', "+
//	   "'"+req.getParameter("founder")+"', "+
//	   "'"+req.getParameter("management")+"', "+
//	   "'"+req.getParameter("partner")+"', "+
//	   "'"+req.getParameter("foundtime")+"', "+
//	   "'"+req.getParameter("competitorglobal")+"', "+
//	   "'"+req.getParameter("competitorchina")+"', "+
//	   "'"+req.getParameter("competitoradvantage")+"', "+
//	   "'"+req.getParameter("regulatory")+"', "+
//	   "'"+req.getParameter("barrier")+"', "+
//	   "'"+req.getParameter("moneyraising")+"', "+
//	   "'"+req.getParameter("equitygiveup")+"', "+
//	   "'"+req.getParameter("burnrate")+"', "+
//	   "'"+req.getParameter("milestone")+"', "+
//         "'"+req.getParameter("useofmoney")+ "')";

	  //
		//String sql2="select ID from entrepreneure where name='"+req.getParameter("name")+"' AND email='"+req.getParameter("email")+"'";
		String caseID=null;
		java.sql.Connection conn = this.connectionManager.getConnection(Include.DBPOOLNAME);
		if(conn == null)
		{
			out.println("<html><body><B>Can not get connection from database connection-pool.</B></body></html>");
			return;
		}
		java.sql.Statement stmt = null;
		try
		{
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select Seq_Entrepreneure_ID.nextVal from dual");
			if(!rs.next()) throw new SQLException("Can't get Entrepreneure.ID from SEQUENCE.");
			else caseID = rs.getString(1);
			stmt.executeUpdate(sql + caseID + ")");
			//rs = stmt.executeQuery(sql2);
			//if(rs.next()==true)
			//{
			//	caseID = rs.getString("ID");
			//}
		}
		catch(SQLException exc)
		{
			out.println("<html><body><B>There is some error occure in the input field.</B><br>" + exc.toString() + "<br><B>Please use back button to verify.  Thanks</B></body></html>");
			return;
		}
		finally
		{
			try
			{
				if(stmt != null) stmt.close();
				if(conn != null) this.connectionManager.freeConnection(Include.DBPOOLNAME, conn);
			}
			catch(java.sql.SQLException ex)
			{
			}
		}

		//display some confirmation page
		BufferedReader inHeader = new BufferedReader(new FileReader(Include.HEADER));
		String s = null;
		while ((s = inHeader.readLine()) != null)
			out.println(s);
		inHeader.close();

		out.println("<table width=580 border=0 cellspacing=0 cellpadding=0>");
		out.println("<tr align=center>");
		out.println("<td class=font6b colspan=2 height=50><H1 align=center><TT><B><font size=5><br><br><br>File Upload</font></B></TT></H1>");
		out.println("<table width=78% border=0><tr><td><font size=2><P align=left>Thanks for the information and your interest in China Internet Group.<br><br>To upload&nbsp; your business plan.&nbsp; Please click <b>Browse</b> button to select");
		out.println("a file, and click upload button.</font> </td></tr></table><FORM ENCTYPE=multipart/form-data ACTION=/cgi-bin/cigfileupload.cgi METHOD=POST>");
		out.println("<TABLE BORDER=0 WIDTH=460><TR><TD ALIGN=RIGHT></TD><TD><INPUT TYPE=hidden NAME=caseid SIZE=35 value=");
		out.println(caseID);
		out.println(" readonly></TD></TR><TR><TD ALIGN=RIGHT> File 1: </TD><TD><INPUT TYPE=FILE NAME=file-to-upload-01 SIZE=35>");
		out.println("</TD></TR><TR><TD ALIGN=RIGHT> File 2: </TD><TD><INPUT TYPE=FILE NAME=file-to-upload-02 SIZE=35></TD>");
		out.println("</TR><TR><TD ALIGN=RIGHT> File 3: </TD><TD><INPUT TYPE=FILE NAME=file-to-upload-03 SIZE=35></TD></TR>");
		out.println("<TR><TD ALIGN=RIGHT> File 4: </TD><TD><INPUT TYPE=FILE NAME=file-to-upload-04 SIZE=35></TD></TR><TR>");
		out.println("<TD COLSPAN=2>&nbsp;<BR></TD></TR><TR><TD colspan=2><div align=center><INPUT TYPE=SUBMIT VALUE=Upload File(s)!>");
		out.println("<INPUT TYPE=RESET VALUE=Reset Form></div></TD></TR></TABLE></FORM></td></tr></table>");

		BufferedReader inFooter = new BufferedReader(new FileReader(Include.FOOTER));
		while ((s = inFooter.readLine()) != null)
			out.println(s);
		inFooter.close();
   }//end of doPost

}
