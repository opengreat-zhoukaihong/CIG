/** Function: entrepreneure to enter info
 *  @author: Debbie Zhang
 *  @version: 1.0.0
 */

package cig.web.en;

import java.io.*;
import java.util.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.InetAddress;
import com.cig.db.DBConnectionManager;


public class evsponsor extends HttpServlet
{
	private DBConnectionManager connectionManager;
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		connectionManager = DBConnectionManager.getInstance();
	}
	public void destroy()
	{
		connectionManager.release();
		super.destroy();
	}
	//-----------------------------------------------

   public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
   {
	  res.setContentType("text/html");
	  PrintWriter out = res.getWriter();
	  String localIP = CbstUtil.getLocalIP("127.0.0.1");

	  //handle checkbox
	  String corpflag="Y";
	  String confflag="Y";
	  String semiflag="Y";
	  if(req.getParameter("corpsponsor")==null)
	corpflag="N";
	  if(req.getParameter("confsponsor")==null)
	confflag="N";
	  if(req.getParameter("semisponsor")==null)
	semiflag="N";

	  //compose sql statement
	  String sql = "insert into evsponsor "+
		 "(FIRSTNAME,LASTNAME,COMPANY,ADDRESS1,ADDRESS2,"+
	   "CITY,STATE,ZIP,PHONE,FAX,EMAIL,COUNTRY,"+
	   "TITLE,TITLEOTHER,"+
	   "CORPSPONSOR,CONFSPONSOR,"+
	   "SEMISPONSOR, ID) "+
		 " values ("+
	   "'"+replace.replacequote(req.getParameter("firstname"))+"', "+
	   "'"+replace.replacequote(req.getParameter("lastname"))+"', "+
	   "'"+replace.replacequote(req.getParameter("company"))+"', "+
	   "'"+replace.replacequote(req.getParameter("address1"))+"', "+
	   "'"+replace.replacequote(req.getParameter("address2"))+"', "+
	   "'"+replace.replacequote(req.getParameter("city"))+"', "+
	   "'"+replace.replacequote(req.getParameter("state"))+"', "+
	   "'"+replace.replacequote(req.getParameter("zip"))+"', "+
	   "'"+replace.replacequote(req.getParameter("phone"))+"', "+
		 "'"+replace.replacequote(req.getParameter("fax"))+"', "+
	   "'"+replace.replacequote(req.getParameter("email"))+"', "+
	   "'"+replace.replacequote(req.getParameter("country"))+"', "+
	   "'"+replace.replacequote(req.getParameter("title"))+"', "+
	   "'"+replace.replacequote(req.getParameter("titleother"))+"', "+
	   "'"+replace.replacequote(corpflag)+"', "+
	   "'"+replace.replacequote(confflag)+"', "+
		 "'"+replace.replacequote(semiflag)+ "', ";

		java.sql.Connection conn = this.connectionManager.getConnection(Include.DBPOOLNAME);
		if(conn == null)
		{
			out.println("<html><body><B>Can not get connection from database connection-pool.</B></body></html>");
			return;
		}
		java.sql.Statement stmt = null;
		try
		{
			stmt = conn.createStatement();
			String caseID = null;
			ResultSet rs = stmt.executeQuery("select seq_evsponsor_id.nextVal from dual");
			if(!rs.next()) throw new SQLException("Can't get Entrepreneure.ID from SEQUENCE.");
			else caseID = rs.getString(1);
			stmt.executeUpdate(sql + caseID + ")");
		}
		catch(SQLException exc)
		{
			out.println("<html><body><B>There is some error occure in the input field.</B><br>" + exc.toString() + "<br><B>Please use back button to verify.  Thanks</B></body></html>");
			return;
		}
		finally
		{
			try
			{
				if(stmt != null) stmt.close();
				if(conn != null) this.connectionManager.freeConnection(Include.DBPOOLNAME, conn);
			}
			catch(java.sql.SQLException ex)
			{
			}
		}

		//display some confirmation page
		BufferedReader inHeader = new BufferedReader(new FileReader(Include.HEADER));
		String s = null;
		while ((s = inHeader.readLine()) != null)
			out.println(s);
		inHeader.close();

		out.println("Dear "+req.getParameter("firstname"));
		out.println("<P align=left>Thank you for being our sponsor! We appreciate your interest and support in China Internet Group events and we will work hard to provide your company with the highest degree of visability, prestige, and notoriety.");
		out.println("<P align=left>Sincerely, <BR>China Internet Group");

		BufferedReader inFooter = new BufferedReader(new FileReader(Include.FOOTER));
		while ((s = inFooter.readLine()) != null)
			out.println(s);
		inFooter.close();
   }//end of doPost

}
